<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$version = '4.8';
$config['ini_version'] = $version;
