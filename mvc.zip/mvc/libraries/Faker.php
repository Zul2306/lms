<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require 'Faker/vendor/autoload.php';

use  Faker\Factory;

class Faker {

    // /**
    //  * Constructor
    //  *
    //  * @access	public
    //  * @param	array	initialization parameters
    //  */
    // function Faker()
    // {
    //     // return Factory::create();
    //     // $this->CI =& get_instance();
    //     //
    //     // if (count($params) > 0)
    //     // {
    //     //     $this->initialize($params);
    //     // }
    //     //
    //     // log_message('debug', 'PDF Class Initialized');
    //
    // }

}

/* End of file faker.php */
