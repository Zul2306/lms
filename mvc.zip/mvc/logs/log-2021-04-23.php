<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-04-23 15:31:31 --> 404 Page Not Found: Frontend/apple-touch-icon.png
