<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-28 09:26:25 --> 404 Page Not Found: Apple-touch-iconpng/index
