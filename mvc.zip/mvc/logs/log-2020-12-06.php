<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-06 14:40:11 --> 404 Page Not Found: Documentation/favicon.ico
ERROR - 2020-12-06 15:35:03 --> 404 Page Not Found: Documentation/favicon.ico
ERROR - 2020-12-06 21:33:36 --> 404 Page Not Found: Documentation/favicon.ico
