<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-12-07 12:53:54 --> 404 Page Not Found: Documentation/favicon.ico
