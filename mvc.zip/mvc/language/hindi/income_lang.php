<?php

$lang['panel_title'] = "आय";
$lang['income_slno'] = "#";
$lang['income_name'] = "नाम";
$lang['income_date'] = "तारीख";
$lang['income_amount'] = "राशि";
$lang['income_user'] = "उपयोगकर्ता";
$lang['income_note'] = "नोट";
$lang['income_file'] = "फ़ाइल";
$lang['income_file_browse'] = "फ़ाइल ब्राउज़ करें";
$lang['income_clear'] = "स्पष्ट";
$lang['income_download'] = "डाउनलोड";
$lang['income_edit'] = "संपादित करें";
$lang['income_delete'] = "हटाना";
$lang['action'] = "कार्रवाई";
$lang['add_income'] = "जोड़ें आय";
$lang['update_income'] = "अद्यतन आय";
