<?php

$lang['panel_title'] = "दृश्यपटल सेटिंग्स";
$lang['frontend_setting_facebook'] = "Facebook";
$lang['frontend_setting_twitter'] = "ट्विटर";
$lang['frontend_setting_linkedin'] = "लिंक्डइन";
$lang['frontend_setting_youtube'] = "यूट्यूब";
$lang['frontend_setting_google'] = "गूगल +";
$lang['frontend_setting_frontend_configaration'] = "दृश्यपटल विन्यास";
$lang['frontend_setting_social'] = "सामाजिक";
$lang['frontend_setting_description'] = "विवरण";
$lang['frontend_setting_teacher_email'] = "शिक्षक ईमेल";
$lang['frontend_setting_teacher_phone'] = "शिक्षक फोन";
$lang['frontend_setting_login_menu_status'] = "लॉगिन मेनू";
$lang['frontend_setting_onlineadmission']  = "ऑनलाइन प्रवेश";
$lang['frontend_setting_enable'] = "सक्षम करें";
$lang['frontend_setting_disable'] = "अक्षम";
$lang['update_frontend_setting'] = "अद्यतन दृश्यपटल सेटिंग";
