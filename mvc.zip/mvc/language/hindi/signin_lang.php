<?php

$lang['signin'] = "हस्ताक्षर में";
