<?php

$lang['panel_title'] = "गतिविधियों की श्रेणी";
$lang['add_title'] = "जोड़ें   क्रियाएँ श्रेणी";
$lang['slno'] = "#";
$lang['activitiescategory_title'] = "शीर्षक";
$lang['activitiescategory_create_date'] = "बनाएँ तारीख";
$lang['activitiescategory_fa_icon'] = "फ़ॉन्ट विस्मयकारी चिह्न";
$lang['action'] = "कार्रवाई";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_activitiescategory'] = "जोड़ें गतिविधियों श्रेणी";
$lang['update_activitiescategory'] = "अद्यतन  क्रियाएँ श्रेणी";
