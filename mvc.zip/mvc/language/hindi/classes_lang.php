<?php

$lang['panel_title'] = "वर्ग";
$lang['add_title'] = "जोड़ें एक वर्ग";
$lang['slno'] = "#";
$lang['classes_name'] = "वर्ग";
$lang['classes_numeric'] = "वर्ग संख्यात्मक";
$lang['teacher_name'] = "शिक्षक का नाम";
$lang['classes_studentmaxID'] = "छात्र मैक्स आईडी";
$lang['classes_note'] = "नोट";
$lang['action'] = "कार्रवाई";
$lang['classes_select_teacher'] = "का चयन करें शिक्षक";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_class'] = "जोड़ें वर्ग";
$lang['update_class'] = "अद्यतन वर्ग";
