<?php

$lang['panel_title'] = "ई-पुस्तकें";
$lang['slno'] = "#";
$lang['ebooks_name'] = "नाम";
$lang['ebooks_author'] = "लेखक";
$lang['ebooks_classes'] = "वर्ग";
$lang['ebooks_authority'] = "प्राधिकरण";
$lang['ebooks_private'] = "निजी";
$lang['ebooks_cover_photo'] = "कवर फोटो";
$lang['ebooks_file'] = "फ़ाइल";
$lang['action'] = "कार्रवाई";
$lang['ebooks_select_class'] = "का चयन करें वर्ग";
$lang['ebooks_select_department'] = "का चयन करें विभाग";
$lang['ebooks_select_teacher'] = "का चयन करें शिक्षक";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_title'] = "जोड़ें ई-पुस्तक";
$lang['add_ebooks'] = "जोड़ें ई-पुस्तक";
$lang['update_ebooks'] = "अद्यतन ई-पुस्तक";
