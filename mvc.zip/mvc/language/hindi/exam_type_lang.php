<?php

$lang['panel_title'] = "परीक्षा प्रकार";
$lang['add_title'] = "जोड़ें एक परीक्षा प्रकार";
$lang['slno'] = "#";
$lang['exam_type_title'] = "शीर्षक";
$lang['exam_type_typeNumber'] = "परीक्षा प्रकार संख्या";
$lang['exam_type_status'] = "स्थिति";
$lang['exam_type_add'] = "जोड़ें";
$lang['action'] = "कार्रवाई";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['print'] = "प्रिंट";
$lang['pdf_preview'] = "पीडीएफ पूर्वावलोकन";
$lang["mail"] = "भेजें पीडीएफ  करने के लिए मेल";
$lang['add_class'] = "जोड़ें परीक्षा प्रकार";
$lang['update_class'] = "अद्यतन परीक्षा प्रकार";
$lang['to'] = "करने के लिए";
$lang['subject'] = "विषय";
$lang['message'] = "संदेश";
$lang['send'] = "भेजें";
$lang['mail_to'] = "के लिए  क्षेत्र  की आवश्यकता";
$lang['mail_valid'] = "के लिए  क्षेत्र चाहिए शामिल एक मान्य ईमेल पते";
$lang['mail_subject'] = "विषय क्षेत्र  की आवश्यकता";
$lang['mail_success'] = "ईमेल भेज सफलतापूर्वक";
$lang['mail_error'] = "उफ़, ईमेल नहीं भेजें";
