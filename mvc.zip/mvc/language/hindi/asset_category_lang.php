<?php

$lang['panel_title'] = "परिसंपत्ति श्रेणी";
$lang['add_title'] = "जोड़ें एक संपत्ति श्रेणी";
$lang['slno'] = "#";
$lang['asset_category'] = "श्रेणी";
$lang['asset_category_add'] = "जोड़ें";
$lang['action'] = "कार्रवाई";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['print'] = "प्रिंट";
$lang['pdf_preview'] = "पीडीएफ पूर्वावलोकन";
$lang["mail"] = "भेजें पीडीएफ  करने के लिए मेल";
$lang['add_asset_category'] = "जोड़ें संपत्ति श्रेणी";
$lang['update_asset_category'] = "अद्यतन संपत्ति श्रेणी";
$lang['to'] = "करने के लिए";
$lang['subject'] = "विषय";
$lang['message'] = "संदेश";
$lang['send'] = "भेजें";
$lang['mail_to'] = "के लिए  क्षेत्र  की आवश्यकता";
$lang['mail_valid'] = "के लिए  क्षेत्र चाहिए शामिल एक मान्य ईमेल पते";
$lang['mail_subject'] = "विषय क्षेत्र  की आवश्यकता";
$lang['mail_success'] = "ईमेल भेज सफलतापूर्वक";
$lang['mail_error'] = "उफ़, ईमेल नहीं भेजें";
