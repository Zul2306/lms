<?php

$lang['panel_title'] = "गोदाम";
$lang['add_title'] = "जोड़ें एक गोदाम";
$lang['slno'] = "#";
$lang['productwarehouse_name'] = "नाम";
$lang['productwarehouse_code'] = "कोड";
$lang['productwarehouse_email'] = "ईमेल";
$lang['productwarehouse_phone'] = "फोन";
$lang['productwarehouse_address'] = "पता";
$lang['action'] = "कार्रवाई";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_productwarehouse'] = "जोड़ें गोदाम";
$lang['update_productwarehouse'] = "अद्यतन गोदाम";
