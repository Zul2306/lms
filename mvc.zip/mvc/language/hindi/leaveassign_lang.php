<?php

$lang['slno'] = "#";
$lang['panel_title'] = "छोड़ आवंटित";
$lang['add_title'] = "जोड़ें एक छोड़ आवंटित";
$lang['leaveassign_assign'] = "आवंटित";
$lang['leaveassign_select_category'] = "का चयन करें श्रेणी";
$lang['leaveassign_categoryID'] = "श्रेणी";
$lang['leaveassign_select_usertype'] = "का चयन करें भूमिका";
$lang['leaveassign_number_of_day'] = "कोई के दिन";
$lang['leaveassign_usertypeID'] = "भूमिका";
$lang['leaveassign_day'] = "भूमिका";
$lang['add_leaveassign'] = "जोड़ें छोड़ आवंटित";
$lang['update_leaveassign'] = "अद्यतन छोड़ आवंटित";
$lang['action'] = "कार्रवाई";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
