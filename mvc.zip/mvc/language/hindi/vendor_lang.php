<?php

$lang['panel_title'] = "विक्रेता";
$lang['add_title'] = "जोड़ें एक विक्रेता";
$lang['slno'] = "#";
$lang['vendor_name'] = "नाम";
$lang['vendor_phone'] = "फोन";
$lang['vendor_email'] = "ईमेल";
$lang['vendor_contact_name'] = "संपर्क करें का नाम";
$lang['vendor_add'] = "जोड़ें";
$lang['action'] = "कार्रवाई";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['print'] = "प्रिंट";
$lang['pdf_preview'] = "पीडीएफ पूर्वावलोकन";
$lang["mail"] = "भेजें पीडीएफ  करने के लिए मेल";
$lang['add_vendor'] = "जोड़ें विक्रेता";
$lang['update_vendor'] = "अद्यतन विक्रेता";
$lang['to'] = "करने के लिए";
$lang['subject'] = "विषय";
$lang['message'] = "संदेश";
$lang['send'] = "भेजें";
$lang['mail_to'] = "के लिए  क्षेत्र  की आवश्यकता";
$lang['mail_valid'] = "के लिए  क्षेत्र चाहिए शामिल एक मान्य ईमेल पते";
$lang['mail_subject'] = "विषय क्षेत्र  की आवश्यकता";
$lang['mail_success'] = "ईमेल भेज सफलतापूर्वक";
$lang['mail_error'] = "उफ़, ईमेल नहीं भेजें";
