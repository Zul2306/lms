<?php

$lang['panel_title'] = "श्रेणी";
$lang['add_title'] = "जोड़ें ए श्रेणी";
$lang['slno'] = "#";
$lang['category_hname'] = "छात्रावास नाम";
$lang['category_class_type'] = "क्लास का प्रकार";
$lang['category_hbalance'] = "छात्रावास शुल्क";
$lang['category_note'] = "नोट";
$lang['category_select_hostel'] = "छात्रावास का चयन करें";
$lang['action'] = "कार्रवाई";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_category'] = "जोड़ें श्रेणी";
$lang['update_category'] = "अद्यतन श्रेणी";
