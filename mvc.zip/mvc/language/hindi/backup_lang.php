<?php

$lang['panel_title'] = "बैकअप";
$lang['slno'] = "#";
$lang['backup_title'] = "बैकअप डेटाबेस";
$lang['backup_submit'] = "डाउनलोड एसक्यूएल";
