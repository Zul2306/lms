<?php

$lang['panel_title'] = "पदों श्रेणियाँ";
$lang['add_title'] = "जोड़ें एक पोस्ट श्रेणियाँ";
$lang['slno'] = "#";
$lang['posts_categories_name'] = "नाम";
$lang['posts_categories_description'] = "विवरण";
$lang['action'] = "कार्रवाई";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_posts_categories'] = "जोड़ें पोस्ट श्रेणियाँ";
$lang['update_posts_categories'] = "अद्यतन पोस्ट श्रेणियाँ";
