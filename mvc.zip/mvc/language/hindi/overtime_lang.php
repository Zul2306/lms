<?php 
$lang['panel_title'] = 'अधिक समय तक';
$lang['add_title'] = 'एक ओवरटाइम जोड़ें';
$lang['slno'] = '#';
$lang['overtime_role'] = 'भूमिका';
$lang['overtime_user'] = 'उपयोगकर्ता';
$lang['overtime_date'] = 'तारीख';
$lang['overtime_hours'] = 'घंटे';
$lang['overtime_total_amount'] = 'कुल रकम';
$lang['action'] = 'कार्य';
$lang['overtime_select_role'] = 'भूमिका का चयन करें';
$lang['overtime_select_user'] = 'उपयोगकर्ता का चयन करें';
$lang['edit'] = 'संपादित करें';
$lang['delete'] = 'हटाएं';
$lang['add_overtime'] = 'ओवरटाइम जोड़ें';
$lang['update_overtime'] = 'ओवरटाइम अपडेट करें';
