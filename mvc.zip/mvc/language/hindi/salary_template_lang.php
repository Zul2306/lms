<?php

$lang['panel_title'] = "वेतन टेम्पलेट";
$lang['add_title'] = "जोड़ें एक वेतन टेम्पलेट";
$lang['slno'] = "#";
$lang['salary_template_salary_grades'] = "वेतन ग्रेड";
$lang['salary_template_basic_salary'] = "मूल वेतन";
$lang['salary_template_overtime_rate'] = "ओवरटाइम दर (प्रति घंटे)";
$lang['salary_template_overtime_rate_not_hour'] = "ओवरटाइम दर";
$lang['salary_template_allowances'] = "भत्ते";
$lang['salary_template_deductions'] = "कटौती";
$lang['salary_template_allowances_label'] = "प्रवेश भत्ते लेबल";
$lang['salary_template_allowances_value'] = "प्रवेश भत्ते मूल्य";
$lang['salary_template_deductions_label'] = "प्रवेश कटौती लेबल";
$lang['salary_template_deductions_value'] = "कटौती मूल्य दर्ज करें";
$lang['salary_template_total_salary_details'] = "कुल वेतन विवरण";
$lang['salary_template_gross_salary'] = "सकल वेतन";
$lang['salary_template_total_deduction'] = "कुल कटौती";
$lang['salary_template_net_salary'] = "नेट वेतन";
$lang['salary_template_allowances_val'] = "भत्ते मूल्य";
$lang['salary_template_deductions_val'] = "कटौती मूल्य";
$lang['add_salary_template'] = "जोड़ें वेतन टेम्पलेट";
$lang['update_salary_template'] = "अद्यतन वेतन टेम्पलेट";
$lang['action'] = "कार्रवाई";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
