<?php

$lang['panel_title'] = "अनुमति";
$lang['slno'] = "#";
$lang['action'] = "कार्रवाई";
$lang['permission_add'] = "जोड़ना";
$lang['permission_view'] = "देखें";
$lang['permission_edit'] = "संपादित करें";
$lang['permission_delete'] = "हटाना";
$lang['select_usertype'] = "का चयन करें भूमिका";
$lang['permission_select_usertype'] = "का चयन करें भूमिका";
$lang['permission_table'] = "अनुमतियां";
$lang['module_name'] = "मॉड्यूल नाम";
$lang['module_description'] = "मॉड्यूल विवरण";
