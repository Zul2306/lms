<?php

$lang['panel_title'] = "अपवाद पृष्ठ";
$lang['exceptionpage_message1'] = "आप  नहीं अधिकृत करने के लिए उपयोग भी तरह  डेटा";
$lang['exceptionpage_message2'] = "कृपया हमसे संपर्क के साथ व्यवस्थापक";
