<?php

$lang['action']      = "कार्रवाई";
$lang['panel_title'] = "मार्क सेटिंग";
$lang['add_title']   = "जोड़ें मार्क सेटिंग";
$lang['edit']        = "संपादित करें";
$lang['delete']      = "हटाना";
$lang['marksetting_slno']          = "#";
$lang['marksetting_mark_type']     = "मार्क प्रकार";
$lang['marksetting_global']        = "वैश्विक";
$lang['marksetting_exam']          = "परीक्षा";
$lang['marksetting_class_wise']    = "वर्ग वार";
$lang['marksetting_exam_wise']     = "परीक्षा वार";
$lang['marksetting_exam_wise_individual']    = "परीक्षा वार व्यक्ति";
$lang['marksetting_subject_wise']            = "विषय वार";
$lang['marksetting_class_exam_wise']         = "वर्ग परीक्षा वार";
$lang['marksetting_class_exam_subject_wise'] = "वर्ग परीक्षा विषय वार";
$lang['marksetting_mark_percentage']         = "मार्क प्रतिशत";
$lang['marksetting_classes']       = "संस्थान";
$lang['marksetting_select_class']  = "का चयन करें वर्ग";
$lang['marksetting_select_markpercentage']  = "का चयन करें Markpercentage";
$lang['marksetting_global']        = "वैश्विक";
$lang['marksetting_class']         = "वर्ग";
$lang['marksetting_class_wise']    = "वर्ग वार";
$lang['marksetting_exam_wise']     = "परीक्षा वार";
$lang['update_mark_setting']       = "अद्यतन मार्क सेटिंग";
$lang['add_mark_setting']          = "जोड़ें मार्क सेटिंग";
