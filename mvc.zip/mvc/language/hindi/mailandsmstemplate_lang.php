<?php

$lang['panel_title'] = "मेल / एसएमएस टेम्पलेट";
$lang['add_title'] = "जोड़ें  टेम्पलेट";
$lang['slno'] = "#";
$lang['mailandsmstemplate_name'] = "नाम";
$lang['mailandsmstemplate_user'] = "उपयोगकर्ता";
$lang['mailandsmstemplate_tags'] = "टैग";
$lang['mailandsmstemplate_template'] = "टेम्पलेट";
$lang['mailandsmstemplate_select_user'] = "का चयन करें उपयोगकर्ता";
$lang['mailandsmstemplate_student'] = "छात्र";
$lang['mailandsmstemplate_parents'] = "माता-पिता";
$lang['mailandsmstemplate_teacher'] = "शिक्षक";
$lang['mailandsmstemplate_accountant'] = "लेखाकार";
$lang['mailandsmstemplate_librarian'] = "लाइब्रेरियन";
$lang['mailandsmstemplate_type'] = "प्रकार";
$lang['mailandsmstemplate_select_type'] = "का चयन करें प्रकार";
$lang['mailandsmstemplate_email'] = "ईमेल";
$lang['mailandsmstemplate_sms'] = "एसएमएस";
$lang['mailandsmstemplate_select_tag'] = "का चयन करें टैग";
$lang['action'] = "कार्रवाई";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_template'] = "जोड़ें टेम्पलेट";
$lang['update_template'] = "अद्यतन टेम्पलेट";
