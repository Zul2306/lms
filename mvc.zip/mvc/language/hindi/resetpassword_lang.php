<?php

$lang['panel_title'] = "रीसेट पासवर्ड";
$lang['slno'] = "#";
$lang['resetpassword_select_users'] = "का चयन करें उपयोगकर्ताओं";
$lang['resetpassword_select_username'] = "का चयन करें उपयोगकर्ता नाम";
$lang['resetpassword_users'] = "उपयोगकर्ताओं";
$lang['resetpassword_username'] = "उपयोगकर्ता नाम";
$lang['resetpassword_new_password'] = "नई पासवर्ड";
$lang['resetpassword_re_password'] = "फिर से पासवर्ड";
$lang['resetpassword'] = "Rseset पासवर्ड";
$lang['update_class'] = "अद्यतन वर्ग";
