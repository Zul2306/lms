<?php

$lang['panel_title'] = "अद्यतन";
$lang['update_file'] = "फ़ाइल";
$lang['update_update'] = "अद्यतन";
$lang['update_update_history'] = "अद्यतन इतिहास";
$lang['update_slno'] = "#";
$lang['update_date'] = "तारीख";
$lang['update_version'] = "संस्करण";
$lang['update_status'] = "स्थिति";
$lang['update_log'] = "लॉग इन करें";
$lang['update_updatelog'] = "अद्यतन लॉग इन करें";
$lang['update_action'] = "कार्रवाई";
$lang['update_success'] = "सफलता";
$lang['update_failed'] = "में विफल रहा है";
$lang['update_file_browse'] = "फ़ाइल ब्राउज़ करें";
$lang['update_clear'] = "स्पष्ट";
