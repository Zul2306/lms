<?php

$lang['panel_title'] = "सामाजिक लिंक";
$lang['add_title'] = "जोड़ें एक सामाजिक लिंक";
$lang['slno'] = "#";
$lang['sociallink_title'] = "शीर्षक";
$lang['sociallink_add'] = "जोड़ें";
$lang['action'] = "कार्रवाई";
$lang['sociallink_role_select'] = "का चयन करें भूमिका";
$lang['sociallink_role'] = "भूमिका";
$lang['sociallink_user_select'] = "का चयन करें उपयोगकर्ता";
$lang['sociallink_photo'] = "फोटो";
$lang['sociallink_user'] = "उपयोगकर्ता";
$lang['sociallink_facebook'] = "Facebook";
$lang['sociallink_twitter'] = "ट्विटर";
$lang['sociallink_linkedin'] = "लिंक्डइन";
$lang['sociallink_googleplus'] = "गूगल प्लस";
$lang['sociallink_userroleID'] = "उपयोगकर्ता भूमिका";
$lang['sociallink_userID'] = "उपयोगकर्ता";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['print'] = "प्रिंट";
$lang['pdf_preview'] = "पीडीएफ पूर्वावलोकन";
$lang["mail"] = "भेजें पीडीएफ  करने के लिए मेल";
$lang['add_sociallink'] = "जोड़ें सामाजिक लिंक";
$lang['update_sociallink'] = "अद्यतन सामाजिक लिंक";
