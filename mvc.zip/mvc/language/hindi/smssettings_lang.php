<?php

$lang['panel_title'] = "एसएमएस सेटिंग्स";
$lang['smssettings_username'] = "उपयोगकर्ता नाम";
$lang['smssettings_password'] = "पासवर्ड";
$lang['smssettings_api_key'] = "एपीआई कुंजी";
$lang['smssettings_accountSID'] = "Accountsid";
$lang['smssettings_authtoken'] = "Auth टोकन";
$lang['smssettings_fromnumber'] = "से संख्या";
$lang['smssettings_authkey'] = "Auth कुंजी";
$lang['smssettings_senderID'] = "प्रेषक आईडी";
$lang['smssettings_muthofun_username'] = "उपयोगकर्ता नाम";
$lang['smssettings_muthofun_password'] = "पासवर्ड";
$lang['smssettings_muthofun_originator'] = "प्रवर्तक";
$lang['save'] = "बचाने के लिए";
