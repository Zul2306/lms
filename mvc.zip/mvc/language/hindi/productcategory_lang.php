<?php

$lang['panel_title'] = "श्रेणी";
$lang['add_title'] = "जोड़ें ए श्रेणी";
$lang['slno'] = "#";
$lang['productcategory_name'] = "नाम";
$lang['productcategory_desc'] = "विवरण";
$lang['action'] = "कार्रवाई";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_productcategory'] = "जोड़ें श्रेणी";
$lang['update_productcategory'] = "अद्यतन श्रेणी";
