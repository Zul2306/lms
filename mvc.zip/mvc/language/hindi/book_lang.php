<?php

$lang['panel_title'] = "किताबें";
$lang['add_title'] = "जोड़ें एक पुस्तक";
$lang['slno'] = "#";
$lang['book_name'] = "नाम";
$lang['book_subject_code'] = "विषय कोड";
$lang['book_author'] = "लेखक";
$lang['book_price'] = "कीमत";
$lang['book_quantity'] = "मात्रा";
$lang['book_rack_no'] = "रैक कोई";
$lang['book_status'] = "स्थिति";
$lang['book_available'] = "उपलब्ध";
$lang['book_unavailable'] = "अनुपलब्ध";
$lang['action'] = "कार्रवाई";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['add_book'] = "जोड़ें पुस्तक";
$lang['update_book'] = "अद्यतन पुस्तक";
