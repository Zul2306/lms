<?php

$lang['panel_title'] = "भुगतान इतिहास";
$lang['add_title'] = "जोड़ें एक वर्ग";
$lang['slno'] = "#";
$lang['paymenthistory_student'] = "छात्र";
$lang['paymenthistory_classes'] = "वर्ग";
$lang['paymenthistory_feetype'] = "शुल्क प्रकार";
$lang['paymenthistory_method'] = "विधि";
$lang['paymenthistory_amount'] = "राशि";
$lang['paymenthistory_date'] = "तारीख";
$lang['paymenthistory_select_paymentmethod'] = "का चयन करें भुगतान विधि";
$lang['paymenthistory_select_student'] = "का चयन करें छात्र";
$lang['paymenthistory_amount'] = "राशि";
$lang['paymenthistory_paymentmethod'] = "भुगतान विधि";
$lang['paymenthistory_payment_by'] = "भुगतान द्वारा";
$lang['action'] = "कार्रवाई";
$lang['view'] = "देखें";
$lang['edit'] = "संपादित करें";
$lang['delete'] = "हटाना";
$lang['Cash'] = "नकद";
$lang['Cheque'] = "चेक";
$lang['Paypal'] = "पेपैल";
$lang['Stripe'] = "धारी";
$lang['PayUmoney'] = "Payumoney";
$lang['update_payment'] = "अद्यतन भुगतान";
