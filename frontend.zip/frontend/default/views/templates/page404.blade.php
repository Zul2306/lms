@layout('views/layouts/master')

@section('content')
	<section id="about" class="about-area area-padding">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
    				<h1> 404 </h1>
				</div> 
			</div>
		</div>
	</section>
@endsection