@layout('views/layouts/master')


@section('content')
    <section id="about" class="about-area area-padding">
    	<div class="container">
            <div class="row">
                <div class="col-xs-12">
                    
                </div>
            </div>
    	</div>
    </section>
@endsection
