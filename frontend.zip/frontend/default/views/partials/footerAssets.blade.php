


	<script src="<?=base_url($frontendThemePath.'assets/js/vendor/jquery-1.12.0.min.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/bootstrap.min.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/owl.carousel.min.js')?>"></script>


    <script src="<?=base_url($frontendThemePath.'assets/js/smoothscroll.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/waypoints.min.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/venobox.min.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/jquery.counterup.min.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/jquery.slicknav.min.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/jquery.easing.1.3.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/plugins.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/js/main.js')?>"></script>

    <script src="<?=base_url($frontendThemePath.'assets/iniPlaylist/iniplaylist.js')?>"></script>

	<script src="<?=base_url($frontendThemePath.'assets/toastr/toastr.min.js')?>"></script>

    <div id="scroll"><i class="fa fa-angle-up"></i></div>


@yield('footerAssetPush')