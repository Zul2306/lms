
	<link rel="apple-touch-icon" href="apple-touch-icon.png">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/css/bootstrap.min.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/css/animate.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/css/venobox.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/css/owl.carousel.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/css/slicknav.min.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/css/font-awesome.min.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/css/style.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/css/responsive.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/iniPlaylist/iniplaylist.css')?>">

    <link type="text/css" rel="stylesheet" href="<?=base_url($frontendThemePath.'assets/toastr/toastr.min.css')?>">

    <script type="text/javascript" src="<?=base_url($frontendThemePath.'assets/js/vendor/modernizr-2.8.3.min.js')?>"></script>


@yield('headerAssetPush')
